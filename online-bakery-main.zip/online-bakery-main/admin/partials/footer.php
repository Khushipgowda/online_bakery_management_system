<!-- Footer Section Starts -->
<div class="footer">
            <div class="wrapper">
                <p class="text-center"><?php echo date("Y"); ?> Developed By Khushi, Neha and Mohana.</a></p>
            </div>
        </div>
        <!-- Footer Section Ends -->

    </body>
</html>