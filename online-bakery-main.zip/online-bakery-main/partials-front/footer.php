
    <!-- footer Section Starts Here -->
    <section class="footer">
        <div class="container text-center">
            <p>Designed By Khushi, Neha and Mohana.</p>
        </div>
    </section>
    <!-- footer Section Ends Here -->

</body>
</html>