# online-bakery
A website for online bakery management system. It consists of two modules - a User module for users to browse through the bakery menu, and an Admin module for the administrator to manage products and orders database.
